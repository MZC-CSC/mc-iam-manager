// Package gfmstyle contains CSS styles for rendering GitHub Flavored Markdown.
package gfmstyle

//go:generate vfsgendev -source="github.com/gobuffalo/github_flavored_markdown/gfmstyle".Assets
