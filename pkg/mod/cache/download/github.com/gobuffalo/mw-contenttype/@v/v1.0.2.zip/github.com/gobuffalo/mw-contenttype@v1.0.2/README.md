Deprecated! Use https://github.com/gobuffalo/middleware/contenttype
