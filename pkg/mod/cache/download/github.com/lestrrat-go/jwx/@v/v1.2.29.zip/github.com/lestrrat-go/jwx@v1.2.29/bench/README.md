# Benchmarks

# Performance Benchmarks

[Measures the performance of github.com/lestrrat-go/jwx](./performance)

# Comparison Benchmarks

[Compares github.com/lestrrat-go/jwx with other libraries](./comparison)
