//go:generate ./gen.sh

// Package jwa defines the various algorithm described in https://tools.ietf.org/html/rfc7518
package jwa
